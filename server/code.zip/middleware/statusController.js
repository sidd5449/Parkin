export const statusController = async(req, res) => {
    res.status(200).json("Established Connection with server");
}